
abstract class BlackjackCommands {
	// Hit Method-------------------------------------------------------------------------------------------------
	protected static Card hit(DeckOfCards card_deck){
		// distribute top card from card_deck to a hand
		Card new_card = card_deck.getTopCard();
		card_deck.RemoveTopCard();
		return new_card;
	}
		
	// Split Method------------------------------------------------------------------------------------------------
	protected static Player split(Player player, DeckOfCards card_deck){ 
		player.getHand2().addCard(player.getHand1().getHand_cards().get(1));
		player.getHand1().removeLastCard();
		player.setWallet(player.getWallet() - player.getBet1());
		player.setBet2(player.getBet1());
			
		player.getHand1().addCard(card_deck.getTopCard());
		card_deck.RemoveTopCard();
		player.getHand2().addCard(card_deck.getTopCard());
		card_deck.RemoveTopCard();
	    return player;  
	}
	
	// Double Up Method-------------------------------------------------------------------------------------------------
		protected static Player doubleup(Player player, DeckOfCards card_deck, int current_hand){
			if (current_hand == 1) {
				// distribute top card from card_deck to a hand	
				player.getHand1().addCard(card_deck.getTopCard());
				player.setWallet(player.getWallet() - player.getBet1());
				player.setBet1(2*player.getBet1());
			}
			else {
				player.getHand2().addCard(card_deck.getTopCard());
				player.setWallet(player.getWallet() - player.getBet2());
				player.setBet2(2*player.getBet2());
			}
			card_deck.RemoveTopCard();
			return player;
		}
		
	// Print Title Method-----------------------------------------------------------------------------------------
	public static void print_title(int num_players,String player_name, String dealer_name) {
		if (num_players == 1) {
			System.out.println("              " + player_name + "'s Hand" + "                         " + "Dealer's Hand" );
		}
		else {
			System.out.println("              " + player_name + "'s Hand" + "                         " + dealer_name + "'s Hand" );
		}
	}
		
	// Show Cards Method------------------------------------------------------------------------------------------
	public static void show_cards(Hand player_hand1, Hand player_hand2, Hand dealer_hand, boolean hid_first, int num_hands){
		if (num_hands == 2 && hid_first) {
			System.out.print("Hand 1: " + player_hand1.getHand_cards() + "       [XXXXX, " + dealer_hand.getHand_cards().get(1) + "]" + System.lineSeparator());
			System.out.print("Hand 2: " + player_hand2.getHand_cards() + System.lineSeparator());
		}
		else if (num_hands == 2) {
			System.out.print("Hand 1: " + player_hand1.getHand_cards() + "       " + dealer_hand.getHand_cards() + System.lineSeparator());
			System.out.print("Hand 2: " + player_hand2.getHand_cards() + System.lineSeparator());
		}
		else if (hid_first) {
			System.out.print("Hand 1: " + player_hand1.getHand_cards() + "       [XXXXX, " + dealer_hand.getHand_cards().get(1) + "]" + System.lineSeparator());
		}
		else {
			System.out.print("Hand 1: " + player_hand1.getHand_cards() + "       " + dealer_hand.getHand_cards() + System.lineSeparator());
		}		
	    return ;  
	}
	
	// Update Hand Value Method-----------------------------------------------------------------------------------
	protected static Hand tot_val_update(Hand player_hand, Hand dealer_hand, boolean dealer) {
		Hand result = new Hand();
		int total_value = 0;
		int ace_count = 0;
		boolean nat_21 = false;

		if (dealer) {
			result = dealer_hand;
			result.setHand_cards(dealer_hand.getHand_cards());
		}
		else {
			result = player_hand;
			result.setHand_cards(player_hand.getHand_cards());
		}				
		
		for (int i = 0; i < result.getHand_cards().size(); i++) {
			if (result.getHand_cards().get(i).getValue() == "J" || result.getHand_cards().get(i).getValue() == "Q" || result.getHand_cards().get(i).getValue() == "K") {
				total_value = total_value + 10;
			}
			else if (result.getHand_cards().get(i).getValue() == "A") {
				total_value = total_value + 11;
				ace_count++;
			}
			else {
				total_value = total_value + Integer.parseInt(result.getHand_cards().get(i).getValue());
			}
		}
		
		if (total_value == 21 && result.getHand_cards().size() == 2) {
			nat_21 = true;
		}
		
		if (total_value > 21 && ace_count > 0) {
			for (int i = 1; i <= ace_count; i++) {
				total_value = total_value - 10;
				if (total_value <= 21) {
					break;
				}
			}
		}
		result.setTotal_value(total_value);
		result.setAce_count(ace_count);
		result.setNat_21(nat_21);
		return result;
	}
	
	// Result of Game--------------------------------------------------------------------------------------------
		protected static int result(Hand player_hand, Hand dealer_hand, boolean no_bust) {
			int outcome = 2;
			
			if (!no_bust) {
				outcome = -1;
			}
			else if (player_hand.isNat_21() && dealer_hand.isNat_21()) {
				outcome = 0;
			}
			else if (player_hand.isNat_21()) {
				outcome = 1;
			}
			else if (dealer_hand.isNat_21()) {
				outcome = -1;
			}
			else if (player_hand.getTotal_value() == dealer_hand.getTotal_value()) {
				outcome = 0;
			}
			else if (player_hand.getTotal_value() > dealer_hand.getTotal_value()) {
				outcome = 1;
			}
			else {
				outcome = -1;
			}
			return outcome;
		}
}
