
public class Player implements Comparable<Player> {
	
	private String name;
	private Hand hand1;
	private Hand hand2;
	private double wallet;
	private double bet1;
	private double bet2;
	private boolean fold;
	private boolean no_bust;
	private boolean dealer;
	private boolean game;
	private int result;
	private int index;
	
	public Player() {
		this.name = "UNDEFINED";
		this.wallet = 0.00;
		this.hand1 = new Hand();
		this.hand2 = new Hand();
		this.bet1 = 0.00;
		this.bet2 = 0.00;
		this.fold = false;
		this.no_bust = true;
		this.dealer = false;
		this.game = true;
		this.result = 2;
		this.index = 0;
	}
	
	public Player(String name, double money) {
		this.name = name;
		this.wallet = money;
		this.hand1 = new Hand();
		this.hand2 = new Hand();
		this.bet1 = 0.00;
		this.bet2 = 0.00;
		this.fold = false;
		this.no_bust = true;
		this.dealer = false;
		this.game = true;
		this.result = 2;
		this.index = 0;
	}
	
	@Override
	public int compareTo(Player other) {
	    return Double.compare(this.wallet, other.wallet);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Hand getHand1() {
		return hand1;
	}

	public void setHand1(Hand hand1) {
		this.hand1 = hand1;
	}

	public Hand getHand2() {
		return hand2;
	}

	public void setHand2(Hand hand2) {
		this.hand2 = hand2;
	}

	public double getWallet() {
		return wallet;
	}

	public void setWallet(double wallet) {
		this.wallet = wallet;
	}

	public double getBet1() {
		return bet1;
	}

	public void setBet1(double bet1) {
		this.bet1 = bet1;
	}

	public double getBet2() {
		return bet2;
	}

	public void setBet2(double bet2) {
		this.bet2 = bet2;
	}

	public boolean isFold() {
		return fold;
	}

	public void setFold(boolean fold) {
		this.fold = fold;
	}

	public boolean isNo_bust() {
		return no_bust;
	}

	public void setNo_bust(boolean no_bust) {
		this.no_bust = no_bust;
	}

	public boolean isDealer() {
		return dealer;
	}

	public void setDealer(boolean dealer) {
		this.dealer = dealer;
	}

	public boolean isGame() {
		return game;
	}

	public void setGame(boolean game) {
		this.game = game;
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
	
	
}
