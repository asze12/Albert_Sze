import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;
import java.util.Random; 
import java.lang.Math;

public class TriantaEna extends TriantaEnaCommands{

	// Main Section-----------------------------------------------------------------------------------------------
	public static void main(String[] args) throws InterruptedException {
		boolean inv_ans = false;
		boolean add_money = false;
		boolean no_bust_all;
		boolean all_fold;
		int num_games = 1;
		int num_players;
		int dealer_index;
		int game_cont;
		double player_money;
		String cont_play;
		String fold;
		String player_action;
		Player[] players;
		DeckOfCards card_deck = new DeckOfCards(2);
		ArrayList<Integer> discard = new ArrayList<Integer>(104);	
		ArrayList<Player> change_dealer;
		
		Scanner scan = new Scanner(System.in).useLocale(Locale.US);  // Reading from System.in
		System.out.println("Enter a number of players (Max 9 people): ");
		do{
			num_players = scan.nextInt(); 
			if ((num_players <= 0 || num_players > 9)) {
				System.out.println("Not valid, please reenter a number of players (Max 9 people): ");
			}
		}while (num_players <= 0 || num_players > 9);
		players = new Player[num_players+1];
		dealer_index = num_players;
		game_cont = num_players+1;
		
		do {
			System.out.println("How much money will each player begin with? ");
			player_money = scan.nextDouble();
			if (player_money <= 0) {
				System.out.println("\tInvalid amount");
			}
		}while (player_money <= 0.0);
		
		for (int i = 0; i < num_players; i++) {
			players[i] = new Player();
			System.out.println("Enter Player's " + (i+1) + " Name:  ");
			players[i].setName(scan.next());
			players[i].setWallet(player_money);
			players[i].setIndex(i);
		}
		players[num_players] = new Player();
		System.out.println("Enter Dealer's Name:  ");
		players[num_players].setName(scan.next());
		players[num_players].setDealer(true);
		players[num_players].setWallet(Math.max(player_money * 3, player_money * num_players * 2));
		players[num_players].setIndex(num_players);
		
		System.out.println(System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + "------------------------------------------------");	
		System.out.println(System.lineSeparator() + System.lineSeparator() + "Let's play Trianta Ena!" + System.lineSeparator());
			
		// Let's Play Trianta Ena!!
		while (game_cont > 1) {
			//re-initiate variables at the beginning of new game
			change_dealer = new ArrayList<Player>(1);
			for ( int i = 0; i < players.length; i++) {
				if (players[i].isGame()) {
					players[i].setHand1(new Hand());
					players[i].setResult(2);
					players[i].setNo_bust(true);
					players[i].setFold(false);
				}
			}
			if (card_deck.getDeck_index().size() == 0) {
				card_deck = new DeckOfCards(2);
				discard = new ArrayList<Integer>(104);	
			}
			game_cont = 0;
			no_bust_all = false;
			all_fold = true;
			player_action = "null";
			
			
			System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + System.lineSeparator() + "X                    " + num_games + " Game"+ "                    X" + System.lineSeparator() + "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"+ System.lineSeparator());
			// Print wallets
			for (int i = 0; i < num_players+1; i++) {
				if (players[i].isGame()) {
					System.out.println(players[i].getName() + "'s remaining money: $" + players[i].getWallet());
				}
			}
			System.out.println(System.lineSeparator() + System.lineSeparator());
			
			// distribute first card	
			for ( int i = 0; i < players.length; i++) {
				if (players[i].isGame() && !players[i].isDealer()) {
					check_deck(card_deck,discard);
					players[i].getHand1().getHand_cards().add(hit(card_deck));
					print_title(players[i],true,false);
				}
			}
			check_deck(card_deck,discard);
			players[dealer_index].getHand1().getHand_cards().add(hit(card_deck));
			print_title(players[dealer_index],true,false);
			
			//Ask in player would like to fold or not and how much the player want to bet
			for ( int i = 0; i < players.length; i++) {
				if (!players[i].isDealer() && players[i].isGame()) {
					System.out.println("-----------------" + players[i].getName() + "'s Turn-----------------");
					System.out.println("If " + players[i].getName() + ", type name and then enter to begin");
					player_action = scan.next();
					System.out.println("    " + players[i].getName()  + System.lineSeparator() + "Money Remaing: $" + players[i].getWallet() + System.lineSeparator());
					print_title(players[i],false,false);
					
					do {
						System.out.println("Would you like to fold? (yes or no)");
						fold = scan.next();			
						
						if (fold.toLowerCase().equals("yes")) {
							inv_ans = false;
							players[i].setFold(true);
						}
						else if (fold.toLowerCase().equals("no")) {
							inv_ans = false;
						}
						else {
							System.out.println("\tInvalid answer");
							inv_ans = true;				
						}
					} while (inv_ans);		
					
					if (!players[i].isFold() && players[i].isGame()) {
						do {
							System.out.println("How much would you like to bet?");
							players[i].setBet1(scan.nextDouble());
							if (players[i].getBet1() > players[i].getWallet()) {
								System.out.println("You do not have enough money to bet that much.");
								inv_ans = true;
								}
							else if (players[i].getBet1() <= 0) {
								System.out.println("You must place a bet to play in this game");
								inv_ans = true;
								}
							else {
								inv_ans = false;
								}
						}while(inv_ans);
						players[i].setWallet(players[i].getWallet() - players[i].getBet1());
					}
					System.out.println(System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator());
				}
			}
			for ( int i = 0; i < players.length; i++) {
				if (!players[i].isFold() && !players[i].isDealer() && players[i].isGame()) {
					all_fold = false;
				}
			}
			
			// distribute second and third card
			for ( int i = 0; i < players.length; i++) {
				if (all_fold) {
					break;
				}
				else if (!players[i].isFold() && players[i].isGame() && !players[i].isDealer()) {
					check_deck(card_deck,discard);
					players[i].getHand1().getHand_cards().add(hit(card_deck));
					check_deck(card_deck,discard);
					players[i].getHand1().getHand_cards().add(hit(card_deck));
					players[i].setHand1(tot_val_update(players[i].getHand1(), new Hand(),false));
					print_title(players[i],true,true);
				}
			}
			if (!all_fold) {
				check_deck(card_deck,discard);
				players[dealer_index].getHand1().getHand_cards().add(hit(card_deck));
				check_deck(card_deck,discard);
				players[dealer_index].getHand1().getHand_cards().add(hit(card_deck));
				print_title(players[dealer_index],true,false);
			}
			
			
			for ( int i = 0; i < players.length; i++) {
				if (!players[i].isFold() && !players[i].isDealer() && players[i].isGame()) {
					System.out.println("-----------------" + players[i].getName() + "'s Turn-----------------");
					System.out.println("If " + players[i].getName() + ", type name and then enter to begin");
					player_action = scan.next();
					print_title(players[i],false,true);
					
					do {
						//Asking player for action
						do {
							System.out.println("Would you like to Hit or Stand?");
							player_action = scan.next();

							// Checking for a valid answer
							if (player_action.toLowerCase().equals("hit") || player_action.toLowerCase().equals("stand")) { 
								inv_ans = false;
							}
							else {
								System.out.println("Invalid answer");
								inv_ans = true;
							}
						}while(inv_ans);
						
						// Hit command
						if (player_action.toLowerCase().equals("hit")) {
							check_deck(card_deck,discard);
							players[i].getHand1().getHand_cards().add(hit(card_deck));
							players[i].setHand1(tot_val_update(players[i].getHand1(), new Hand(),false));
							print_title(players[i],false,true);
						}
						else {
							no_bust_all = true;
						}
						
						//If player bust on hand
						if (players[i].getHand1().getTotal_value() > 31) {
							players[i].setNo_bust(false);
							System.out.println("You busted!");
							java.util.concurrent.TimeUnit.SECONDS.sleep(2);
						}
					}while(players[i].isNo_bust() && !player_action.toLowerCase().equals("stand"));
					System.out.println(System.lineSeparator() + System.lineSeparator() +  System.lineSeparator() +  System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator());
				}			
			}
			
			if (no_bust_all) {
				System.out.println("-----------------Dealer's Turn-----------------");
				players[dealer_index].setHand1(tot_val_update(players[dealer_index].getHand1(), new Hand(),false));
				// Dealer will continue hitting until he is over 27
				while (players[dealer_index].getHand1().getTotal_value() < 27) {
					check_deck(card_deck,discard);
					players[dealer_index].getHand1().getHand_cards().add(hit(card_deck));
					players[dealer_index].setHand1(tot_val_update(players[dealer_index].getHand1(), new Hand(),false)); 
					//print_title(players[dealer_index],false,true);
				}
				//If the dealer is over 21, he busts
				if (players[dealer_index].getHand1().getTotal_value() > 31) {
					players[dealer_index].setNo_bust(false);
				} 
			}
		
			for ( int i = 0; i < players.length; i++) {
				if (all_fold) {
					break;
				}
				else if (!players[i].isFold() && players[i].isGame() && !players[i].isDealer()) {
					print_title(players[i],false,true);
					players[i].setResult(result(players[i].getHand1(), players[dealer_index].getHand1(), players[i].isNo_bust()));
				}
			}
			
			if (!all_fold) {
				print_title(players[dealer_index],false,true);
				System.out.println("------------------------------------------------");
			}

			//Determines who wins
			for ( int i = 0; i < players.length; i++) {
				if (!players[i].isFold() && !players[i].isDealer() && players[i].isGame()) {
					print_title(players[i],false,false);
					if (players[i].getResult() == 1) {
						System.out.println("\tYou won! Winnings: $" + 2*players[i].getBet1());
						players[i].setWallet(players[i].getWallet() + 2*(players[i].getBet1()));
						players[dealer_index].setWallet(players[dealer_index].getWallet() - players[i].getBet1());  
					}
					else if (players[i].getResult() == -1){
						System.out.println("\tHouse wins, better luck next time. Loss: $" + players[i].getBet1());
						players[dealer_index].setWallet(players[dealer_index].getWallet() + players[i].getBet1());
					}				
					else {
						System.out.println("\tYou busted, House wins! Better luck next time! Loss: $"  + players[i].getBet1());
						players[dealer_index].setWallet(players[dealer_index].getWallet() + players[i].getBet1());
					}
				}
			}
			if (!all_fold) {
				print_title(players[dealer_index],false,false);
				java.util.concurrent.TimeUnit.SECONDS.sleep(1);
			}
			
			//Asks the player if he/she would like to continue and add more money.
			System.out.println(System.lineSeparator());
			System.out.println("------------------------------------------------");
			
			for ( int i = 0; i < players.length; i++) {
				if (!players[i].isDealer() && players[i].isGame()) {
					System.out.println("-------------Player " + players[i].getName() + "------------------------");
					do{
						//If the player no longer has money
						if (players[i].getWallet() <= 0.0) {
							System.out.println("You do not have anymore money. Would you like to exchange more money? (yes or no) ");
							cont_play = scan.next();
						}
						//Asks the player if he/she would like to continue
						else {
							System.out.println("Would you like to continue playing? (yes or no)");
							cont_play = scan.next();
						}
				
						if (cont_play.toLowerCase().equals("yes")) {
							players[i].setGame(true);
							inv_ans = false;
						}
						else if (cont_play.toLowerCase().equals("no")){
							players[i].setGame(false);
							inv_ans = false;
						}
						else {
							System.out.println("\tInvalid answer");
							inv_ans = true;					
						}
					} while (inv_ans);
					
					// If wallet is empty and player would like to continue the game
					if (players[i].getWallet() <= 0.0 && players[i].isGame()) {
						add_money = true;
					}
					//Asks if the player would like to exchange more money
					else if (players[i].isGame()) {
						do {
							System.out.println("Would you like to exchange more money? (yes or no)");
							cont_play = scan.next();			
							
							if (cont_play.toLowerCase().equals("yes")) {
								inv_ans = false;
								add_money = true;
							}
							else if (cont_play.toLowerCase().equals("no")) {
								inv_ans = false;
								add_money = false;
							}
							else {
								System.out.println("\tInvalid answer");
								inv_ans = true;				
							}
						} while (inv_ans);	
					}
					else {
						add_money = false;
					}
					
					//If player would like to add more money
					if (add_money) {
						do {
							System.out.println("How much money would you like to add? ");
							player_money = scan.nextDouble();
							if (player_money < 0.0) {
								System.out.println("\tInvalid amount.");
							}
						}while (player_money < 0.0);
						players[i].setWallet(players[i].getWallet() + player_money);
					}
				}
			}
			for ( int i = 0; i < players.length; i++) {
				if (players[i].isGame()) {
					if (players[i].isDealer() && players[i].getWallet() <= 0) {
						players[i].setGame(false);
						System.out.println("Dealer has gone bankrupt!");
						players[i].setDealer(false);
					}
					else {
						game_cont += 1;
					}
					if (players[i].getWallet() > players[dealer_index].getWallet() && !players[i].isDealer()) {
						change_dealer.add(players[i]);
					}
				}
			}
			
			if(game_cont > 1) {
				Collections.sort(change_dealer, Collections.reverseOrder());
				if(players[dealer_index].isDealer()) {
					for (int i = 0; i < change_dealer.size(); i ++) {
						do {
							System.out.println(change_dealer.get(i).getName() + " Would you like to be the new dealer? (yes or no)");
							cont_play = scan.next();			
							
							if (cont_play.toLowerCase().equals("yes")) {
								inv_ans = false;
								players[dealer_index].setDealer(false);
								dealer_index = change_dealer.get(i).getIndex();
								players[dealer_index].setDealer(true);	
							}
							else if (cont_play.toLowerCase().equals("no")) {
								inv_ans = false;
							}
							else {
								System.out.println("\tInvalid answer");
								inv_ans = true;				
							}
						} while (inv_ans);
						if (cont_play.toLowerCase().equals("yes")) { 
							break;
						}
					}
				}
				else {
					System.out.println("New dealer is: " + change_dealer.get(0).getName());
					dealer_index = change_dealer.get(0).getIndex();
					players[dealer_index].setDealer(true);
					java.util.concurrent.TimeUnit.SECONDS.sleep(1);
				}
			}
			
			// If the player is done playing or not
			if (game_cont <= 1) {
				System.out.println(System.lineSeparator() + "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$");
				for ( int i = 0; i < players.length; i++) {
					System.out.println("\t" + players[i].getName() + " is leaving with : $" + players[i].getWallet());
				}
				System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"+ System.lineSeparator());
			}
			else {
				System.out.println(System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator());
			}
			num_games++;
			}//end game
		//once finished
		scan.close();
		}
	}