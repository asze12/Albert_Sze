import java.util.ArrayList;
import java.util.Collections;

abstract class TriantaEnaCommands extends BlackjackCommands{
	// Print Title Method-----------------------------------------------------------------------------------------
	public static void print_title(Player player, boolean hid_first, boolean bet_placed) {
		if (player.isDealer()) {
			System.out.println(player.getName() + "'s (dealer's) hand: " + player.getHand1().getHand_cards());
		}
		else if (hid_first) {
			System.out.printf(player.getName() + "'s hand: [XXXXX");
			for (int i = 1; i < player.getHand1().getHand_cards().size(); i++) {	
				System.out.printf( ", " + player.getHand1().getHand_cards().get(i));
			}
			if (bet_placed) {
				System.out.println("]\tbet: $" + player.getBet1());
			}
			else {
				System.out.println("]");
			}
		}
		else if (bet_placed) {
			System.out.println(player.getName() + "'s hand: " + player.getHand1().getHand_cards() + "\tbet: $" + player.getBet1());
		}
		else if (player.getResult() == 2) {
			System.out.println(player.getName() + "'s hand: " + player.getHand1().getHand_cards());
		}	
		else {
			System.out.printf(player.getName() + "'s hand: " + player.getHand1().getHand_cards());
		}
	    return ;  
	}
	
	// Update Hand Value Method-----------------------------------------------------------------------------------
		protected static Hand tot_val_update(Hand player_hand, Hand dealer_hand, boolean dealer) {
			Hand result = new Hand();
			int total_value = 0;
			int ace_count = 0;
			boolean nat_31 = false;
			String suit = "suit";
			boolean same_suit = false;
			boolean wild_14 = false;

			if (dealer) {
				result = dealer_hand;
				result.setHand_cards(dealer_hand.getHand_cards());
			}
			else {
				result = player_hand;
				result.setHand_cards(player_hand.getHand_cards());
			}				
			
			for (int i = 0; i < result.getHand_cards().size(); i++) {
				if (i == 0) {
					suit = result.getHand_cards().get(i).getSuit();
				}
				else if (result.getHand_cards().get(i).getSuit() == suit) {
					same_suit = true;					
				}
				else {
					suit = "suit";
					same_suit =false;
				}
				
				if (result.getHand_cards().get(i).getValue() == "J" || result.getHand_cards().get(i).getValue() == "Q" || result.getHand_cards().get(i).getValue() == "K") {
					total_value = total_value + 10;
				}
				else if (result.getHand_cards().get(i).getValue() == "A") {
					total_value = total_value + 11;
					ace_count++;
				}
				else {
					total_value = total_value + Integer.parseInt(result.getHand_cards().get(i).getValue());
				}
			}
			
			if (total_value == 31 && result.getHand_cards().size() == 3) {
				nat_31 = true;
			}
			else if (total_value == 14 && same_suit) {
				wild_14 = true;
			}
			else if (total_value > 31 && ace_count > 0) {
				total_value = total_value - 10;
			}
			result.setTotal_value(total_value);
			result.setAce_count(ace_count);;
			result.setNat_31(nat_31);
			result.setWild_14(wild_14);
			return result;
		}
		
		// Result of Game--------------------------------------------------------------------------------------------
		protected static int result(Hand player_hand, Hand dealer_hand, boolean no_bust) {
			int outcome = 2;
			
			if (!no_bust) {
				outcome = -2;
			}
			else if (dealer_hand.getTotal_value() > 31 || player_hand.isWild_14()) {
				outcome = 1;
			}
			else if (dealer_hand.isNat_31()) {
				outcome = -1;
			}
			else if (player_hand.isNat_31() || (player_hand.getTotal_value() > dealer_hand.getTotal_value())) {
				outcome = 1;
			}
			else {
				outcome = -1;
			}
			return outcome;
		}
			
		//Check deck method
		protected static void check_deck(DeckOfCards deck, ArrayList<Integer> discard_pile) {
			if (deck.getDeck_index().size() == 0){
				Collections.shuffle(discard_pile);
				deck.setDeck_index(discard_pile);
				discard_pile = new ArrayList<Integer>(104);	
			}
			else {
				discard_pile.add(deck.getDeck_index().get(0));
			}
			return;
		}
		
}
