import java.util.ArrayList;

public class Hand {
	
	private  ArrayList<Card> hand_cards;
	private int total_value;
	private int ace_count;
	private boolean nat_21;
	private boolean nat_31;
	private boolean wild_14;
	
	Hand(){
		this.hand_cards = new ArrayList<Card>(26);
		this.total_value = 0;
		this.ace_count = 0;
		this.nat_21 = false;
		this.nat_31 = false;
		this.wild_14 = false;
	}

	public ArrayList<Card> getHand_cards() {
		return hand_cards;
	}

	public void setHand_cards(ArrayList<Card> hand_cards) {
		this.hand_cards = hand_cards;
	}

	public int getTotal_value() {
		return total_value;
	}

	public void setTotal_value(int total_value) {
		this.total_value = total_value;
	}

	public int getAce_count() {
		return ace_count;
	}

	public void setAce_count(int ace_count) {
		this.ace_count = ace_count;
	}

	public boolean isNat_21() {
		return nat_21;
	}

	public void setNat_21(boolean nat_21) {
		this.nat_21 = nat_21;
	}

	public boolean isNat_31() {
		return nat_31;
	}

	public void setNat_31(boolean nat_31) {
		this.nat_31 = nat_31;
	}

	public boolean isWild_14() {
		return wild_14;
	}

	public void setWild_14(boolean wild_14) {
		this.wild_14 = wild_14;
	}
	
	public void addCard(Card NewCard) {
		hand_cards.add(NewCard);
	}
	
	public void removeLastCard() {
		hand_cards.remove(hand_cards.size()-1);
	}
}