import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;
import java.util.Random; 

public class Blackjack extends BlackjackCommands{
		
	// Main Section-----------------------------------------------------------------------------------------------
	public static void main(String[] args) throws InterruptedException {
		//Initiate variables
		boolean  game = true;
		boolean inv_ans = false;
		boolean add_money = false;
		boolean no_bust;
		boolean no_bust1;
		boolean no_bust2;
		boolean dealer_bust;
		boolean able_split;
		boolean valid_split;
		int num_games = 1;
		int num_hands;
		int current_hand;
		int num_players;
		int hand1_result;
		int hand2_result;
		double bet;
		double player_money;
		Hand hand_in_play;
		Hand result_hand;
		String cont_play;
		String player1_name;
		String player2_name = null;
		String player_action;
		Player player1;
		Dealer dealer;
		Random rand = new Random(); 
		int rnd;
		
		Scanner scan = new Scanner(System.in).useLocale(Locale.US);  // Reading from System.in
		System.out.println("Enter a number of players (1 or 2): ");
		do{
			num_players = scan.nextInt(); 
			if ((num_players < 1 || num_players > 2)) {
				System.out.println("Not valid, please reenter a number of players (1 or 2): ");
			}
		}while (num_players < 0 || num_players > 2); 
		
		if (num_players == 1) {
			System.out.println("Enter Player's Name:  ");
			player1_name = scan.next();
			do {
				System.out.println("How much money would you like to exchange? ");
				player_money = scan.nextDouble();
				if (player_money <= 0) {
					System.out.println("\tYou need money to buy in.");
				}
			}while (player_money <= 0.0);
			dealer = new Dealer();
		}
		else {
			System.out.println("Enter Gambler's Name:  ");
			player1_name = scan.next();			
			do {
				System.out.println("How much money would you like to exchange? ");
				player_money = scan.nextDouble();
				if (player_money <= 0) {
					System.out.println("\tYou need money to buy in.");
				}
			}while (player_money <= 0.0);			
			System.out.println("Enter Dealer's Name:  ");
			player2_name = scan.next();
			dealer = new Dealer(player2_name);
		}
		player1= new Player(player1_name,player_money);
		
		System.out.println(System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + "------------------------------------------------");	
		System.out.println(System.lineSeparator() + System.lineSeparator() + "Let's play Blackjack!" + System.lineSeparator());
		
		// Let's Play Blackjack!!
		while (game) {
			//re-initiate variables at the beginning of new game
			player1.setHand1(new Hand());
			player1.setHand2(new Hand());
			dealer.setHand(new Hand());
			result_hand = new Hand();
			rnd = rand.nextInt(100);
			num_hands = 1;
			current_hand = 1;
			hand1_result = 0;
			hand2_result = 0;
			dealer_bust = false;
			no_bust = true;
			no_bust1 = true;
			no_bust2 = true;
			able_split = true;
			valid_split = false;
			player_action = "null";
			System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX" + System.lineSeparator() + "X                    " + num_games + " Game"+ "                    X" + System.lineSeparator() + "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"+ System.lineSeparator());
			System.out.println("    " + player1.getName()  + System.lineSeparator() + "Money Remaing: $" + player1.getWallet() + System.lineSeparator());

			// Asks the player how much to bet.
			do {
				System.out.println("Place your bet now.");
				player1.setBet1(scan.nextDouble());
				if (player1.getBet1() > player1.getWallet()) {
					System.out.println("You do not have enough money to bet that much.");
					inv_ans = true;
					}
				else if (player1.getBet1() <= 0) {
					System.out.println("You must place a bet to play in this game");
					inv_ans = true;
					}
				else {
					inv_ans = false;
					}
				}while(inv_ans);
			player1.setWallet(player1.getWallet() - player1.getBet1()); 
			
			// Get a new shuffled deck
			DeckOfCards card_deck = new DeckOfCards();
			
			// distribute first 2 cards	
			print_title(num_players,player1.getName(),dealer.getName());
			for ( int i = 0; i < 2; i++) {
				player1.getHand1().addCard(hit(card_deck));
				dealer.getHand().addCard(hit(card_deck));
				}
			show_cards(player1.getHand1(), player1.getHand2(), dealer.getHand(), true, num_hands);
			player1.setHand1(tot_val_update(player1.getHand1(), new Hand(),false));
			
			System.out.println("-----------------" + player1.getName() + "s Turn-----------------");			
			do {
				//If there are two hands do to splitting
				if (current_hand == 1) {
					hand_in_play = player1.getHand1();
					bet = player1.getBet1();
				}
				else {
					hand_in_play = player1.getHand2();
					bet = player1.getBet2();
				}

				//Asking player for action
				do {
					if (!able_split) {
						System.out.println("For hand " + current_hand);
					}
					
					if (able_split && hand_in_play.getHand_cards().get(0).getValue() == hand_in_play.getHand_cards().get(1).getValue() && 2*bet <= player1.getWallet()) {
						System.out.println("Would you like to Double up, Hit, Stand, or Split?");
						valid_split = true;
					}
					else if (2*bet <= player1.getWallet()) {						
						System.out.println("Would you like to Double up, Hit or Stand?");
					}
					else {
						System.out.println("Would you like to Hit or Stand?");
					}
					player_action = scan.next();

					// Checking for a valid answer
					if (player_action.toLowerCase().equals("hit") || player_action.toLowerCase().equals("stand") || (2*bet <= player1.getWallet() && player_action.toLowerCase().equals("double"))) { 
						inv_ans = false;
					}
					else if (valid_split && player_action.toLowerCase().equals("split")) {
							inv_ans = false;
							valid_split = false;
						}
					else if (!player_action.toLowerCase().equals("up")){
						System.out.println("Invalid answer");
						inv_ans = true;
					}
				}while(inv_ans);
				
				// Hit command
				if (player_action.toLowerCase().equals("hit")) {
					hand_in_play.getHand_cards().add(hit(card_deck));
					hand_in_play = tot_val_update(hand_in_play, new Hand(),false);
				}
				// Split command
				else if(player_action.toLowerCase().equals("split")){
					num_hands++;
					able_split = false;					
					player1 = split(player1,card_deck);
					hand_in_play = player1.getHand1();					
					hand_in_play = tot_val_update(hand_in_play, new Hand(),false);
					player1.setHand2(tot_val_update(player1.getHand2(), new Hand(),false));
				}
				else if(player_action.toLowerCase().equals("double")) {
					player1 = doubleup(player1,card_deck,current_hand);
					hand_in_play = tot_val_update(hand_in_play, new Hand(),false);
				}
				
				//Print updated hands
				print_title(num_players,player1.getName(),dealer.getName());
				if (current_hand == 1) {
					show_cards(hand_in_play, player1.getHand2(), dealer.getHand(), true, num_hands);
				}
				else {
					show_cards(player1.getHand1(), hand_in_play, dealer.getHand(), true, num_hands);
				}
				hand_in_play = tot_val_update(hand_in_play, new Hand(),false);
				
				//Update proper hand if hand is split
				if (current_hand == 1) {
					player1.setHand1(hand_in_play);
				}
				else {
					player1.setHand2(hand_in_play);
				}
				
				//If stand or double down change to next hand
				if(player_action.toLowerCase().equals("stand") || (player_action.toLowerCase().equals("double") && hand_in_play.getTotal_value() <= 21)) {
					current_hand++;
				}
				//If player bust on hand
				else if (hand_in_play.getTotal_value() > 21) {
					no_bust = false;
					//If cards were split and first hand busts
					if (current_hand == 1) {
						no_bust1 = false;
						if (num_hands == 2) {
							no_bust = true;
						}
					}
					//If cards were split and second hand busts
					else if (current_hand == 2) {
						no_bust2 = no_bust;
					}
					current_hand++;
				}
			}while(no_bust && !player_action.toLowerCase().equals("stand") && !player_action.toLowerCase().equals("double") || current_hand <= num_hands);
			
			if (num_hands == 2 && no_bust1 && !no_bust2) {
				no_bust =true;
			}
			
			if (no_bust) {
				System.out.println("-----------------Dealer's Turn-----------------");
				print_title(num_players,player1.getName(),dealer.getName());
				show_cards(player1.getHand1(), player1.getHand2(), dealer.getHand(), false, num_hands);
				dealer.setHand(tot_val_update(new Hand(), dealer.getHand() ,true));
				// Dealer will continue hitting until he is over 17
				while (dealer.getHand().getTotal_value() < 17) {
					dealer.getHand().addCard(hit(card_deck));
					show_cards(player1.getHand1(), player1.getHand2(), dealer.getHand(), false, num_hands);
					dealer.setHand(tot_val_update(new Hand(), dealer.getHand() ,true)); 
				}
				//If the dealer is over 21, he busts
				if (dealer.getHand().getTotal_value() > 21) {
					dealer_bust = true;
				} 
			}
			
			System.out.println("------------------------------------------------");
			//Determines who wins
			//If dealer busted
			if (dealer_bust) {
				if (no_bust1 && no_bust2) {
					System.out.println("You won!" + System.lineSeparator() + player1.getName() + " won $" + 2*(player1.getBet1()+player1.getBet2()));
					player1.setWallet(player1.getWallet() + 2*(player1.getBet1()+player1.getBet2()));
				}
				else if (no_bust1) {
					System.out.println("You won!" + System.lineSeparator() + player1.getName() + " won $" + 2*(player1.getBet1()));
					player1.setWallet(player1.getWallet() + 2*(player1.getBet1()));
				}
				else {
					System.out.println("You won!" + System.lineSeparator() + player1.getName() + " won $" + 2*(player1.getBet2()));
					player1.setWallet(player1.getWallet() + 2*(player1.getBet2()));
				}
			}
			else if(no_bust1 || (no_bust2 && num_hands == 2)) {
				hand1_result = result(player1.getHand1(), dealer.getHand(), no_bust1);
				hand2_result = result(player1.getHand2(), dealer.getHand(), no_bust2);
				
				if (num_hands == 2) {				
					if(hand1_result == 0 && hand2_result == 0) {
						System.out.println("\tYou tied both hands.");
						player1.setWallet(player1.getWallet() + (player1.getBet1() + player1.getBet2()));
					}
					else if (hand1_result == 0 && hand2_result == -1) {
						System.out.println("\tYou tied Hand 1 and lost Hand 2." + System.lineSeparator() + player1.getName() + " lost $" + (player1.getBet2()));
						player1.setWallet(player1.getWallet() + player1.getBet1());
					}
					else if (hand1_result == 0 && hand2_result == 1) {
						System.out.println("\tYou tied Hand 1 and won Hand 2!" + System.lineSeparator() + player1.getName() + " won $" + 2*(player1.getBet2()));
						player1.setWallet(player1.getWallet() + player1.getBet1() + 2*player1.getBet2());
					}
					else if (hand1_result == 1 && hand2_result == 0) {
						System.out.println("\tYou won Hand 1 and tied Hand 2!" + System.lineSeparator() + player1.getName() + " won $" + 2*(player1.getBet1()));
						player1.setWallet(player1.getWallet() + 2*player1.getBet1() + player1.getBet2());
					}
					else if (hand1_result == 1 && hand2_result == -1) {
						System.out.println("\tYou won Hand 1 and lost Hand 2!" + System.lineSeparator() + player1.getName() + " won $" + 2*(player1.getBet1()));
						player1.setWallet(player1.getWallet() + 2*player1.getBet1());
					}
					else if (hand1_result == 1 && hand2_result == 1) {
						if (rnd%2 == 0) {
							System.out.println("Winner Winner Chicken Dinner");
						}
						System.out.println("\tYou won both hands!" + System.lineSeparator() + player1.getName() + " won $" + 2*(player1.getBet1() + player1.getBet2()));
						player1.setWallet(player1.getWallet() + 2*(player1.getBet1() + player1.getBet2()));
					}
					else if (hand1_result == -1 && hand2_result == 0) {
						System.out.println("\tYou lost Hand 1 and tied Hand 2." + System.lineSeparator() + player1.getName() + " lost $" + (player1.getBet1()));
						player1.setWallet(player1.getWallet() + player1.getBet2());
					}
					else if (hand1_result == -1 && hand2_result == 1) {
						System.out.println("\tYou lost Hand 1 and won Hand 2." + System.lineSeparator() + player1.getName() + " won $" + 2*(player1.getBet2()));
						player1.setWallet(player1.getWallet() + 2*player1.getBet2());
					}
					else {
						System.out.println("\tHouse wins, better luck next time." + System.lineSeparator() + player1.getName() + " lost $" + (player1.getBet1() + player1.getBet2()));
					}
				}
				else {
					if(hand1_result == 0) {
						System.out.println("\tYou tied.");
						player1.setWallet(player1.getWallet() + player1.getBet1());
					}
					else if (hand1_result == 1) {
						if (rnd%2 == 0) {
							System.out.println("Winner Winner Chicken Dinner");
						}
						System.out.println("\tYou won!" + System.lineSeparator() + player1.getName() + " won $" + 2*(player1.getBet1()));
						player1.setWallet(player1.getWallet() + 2*(player1.getBet1()));
					}
					else {
						System.out.println("\tHouse wins, better luck next time." + System.lineSeparator() + player1.getName() + " lost $" + (player1.getBet1()));
					}						
				}
			}
			else {
				System.out.println("You busted, House wins! Better luck next time!" + System.lineSeparator() + player1.getName() + " lost $" + num_hands*player1.getBet1());
			}
			
			//Asks the player if he/she would like to continue and add more money.
			java.util.concurrent.TimeUnit.SECONDS.sleep(1);
			System.out.println(System.lineSeparator());
			System.out.println("------------------------------------------------");
			do{
				//If the player no longer has money
				if (player1.getWallet() <= 0.0) {
					System.out.println("You do not have anymore money. Would you like to exchange more money? (yes or no) ");
					cont_play = scan.next();
				}
				//Asks the player if he/she would like to continue
				else {
					System.out.println("Would you like to continue playing? (yes or no)");
					cont_play = scan.next();
				}
		
				if (cont_play.toLowerCase().equals("yes")) {
					game = true;
					inv_ans = false;
				}
				else if (cont_play.toLowerCase().equals("no")){
					game = false;
					inv_ans = false;
				}
				else {
					System.out.println("\tInvalid answer");
					inv_ans = true;					
				}
			} while (inv_ans);
			
			// If wallet is empty and player would like to continue the game
			if (player1.getWallet() <= 0.0 && game) {
				add_money = true;
			}
			//Asks if the player would like to exchange more money
			else if (game) {
				do {
					System.out.println("Would you like to exchange more money? (yes or no)");
					cont_play = scan.next();			
					
					if (cont_play.toLowerCase().equals("yes")) {
						inv_ans = false;
						add_money = true;
					}
					else if (cont_play.toLowerCase().equals("no")) {
						inv_ans = false;
						add_money = false;
					}
					else {
						System.out.println("\tInvalid answer");
						inv_ans = true;				
					}
				} while (inv_ans);	
			}
			else {
				add_money = false;
			}
			
			//If player would like to add more money
			if (add_money) {
				do {
					System.out.println("How much money would you like to add? ");
					player_money = scan.nextDouble();
					if (player_money < 0.0) {
						System.out.println("\tInvalid amount.");
					}
				}while (player_money < 0.0);
				player1.setWallet(player1.getWallet() + player_money);
			}		
			
			// If the player is done playing or not
			if (!game) {
				System.out.println(System.lineSeparator() + "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$" + System.lineSeparator() + "        " + player1.getName() + " is leaving with : $" + player1.getWallet() + System.lineSeparator() + "$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$"+ System.lineSeparator());
			}
			else {
				System.out.println(System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator() + System.lineSeparator());
			}
			num_games++;
			}//end game
		//once finished
		scan.close();
		}
	}

