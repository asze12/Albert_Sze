// Java program to demonstrate working of ArrayList in Java 
import java.io.*; 
import java.util.*;

public class DeckOfCards {
	private Card[] deck;
	private ArrayList<Integer> deck_index;
	
	DeckOfCards(){
		this.deck = new Card[52];
		this.deck_index = new ArrayList<Integer>(52);
		//this.initiate();
		//DeckOfCards new_deck = new DeckOfCards();
		int suit_type = 0;
		String[] value = {"2","3","4","5","6","7","8","9","10","J","Q","K","A"};
		String[] suit = {"Diamonds","Clubs","Hearts","Spades"};
		for (int i = 0; i < deck.length; i++) {
			deck_index.add(i);
			suit_type = i/13;
			deck[i] = new Card(value[i%13],suit[suit_type%4]);
			}
		this.Shuffle();
	}
	
	DeckOfCards(int num_decks) {
		this.deck = new Card[52*num_decks];
		this.deck_index = new ArrayList<Integer>(52*num_decks);
		//this.initiate();
		//DeckOfCards new_deck = new DeckOfCards();
		int suit_type = 0;
		String[] value = {"2","3","4","5","6","7","8","9","10","J","Q","K","A"};
		String[] suit = {"Diamonds","Clubs","Hearts","Spades"};
		for (int i = 0; i < deck.length; i++) {
			deck_index.add(i);
			suit_type = i/13;
			deck[i] = new Card(value[i%13],suit[suit_type%4]);
			}
		this.Shuffle();
	}

	private void Shuffle() {
		Collections.shuffle(deck_index);
	}

	public Card[] getDeck() {
		return deck;
	}

	public void setDeck(Card[] deck) {
		this.deck = deck;
	}

	public ArrayList<Integer> getDeck_index() {
		return deck_index;
	}

	public void setDeck_index(ArrayList<Integer> deck_index) {
		this.deck_index = deck_index;
	}
	
	public Card getTopCard() {
		return deck[deck_index.get(0)];
	}
	public void RemoveTopCard() {
		deck_index.remove(0);
	}
	
}
