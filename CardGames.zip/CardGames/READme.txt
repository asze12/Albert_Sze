Albert Sze
10/15/18

This code can play both Blackjack and Trianta Ena

BLACKJACK
Change director to the src folder. 
Then compile Blackjack.java using the following code:
javac  Blackjack.java
then run the code using:
java Blackjack

TRIANTA ENA
Change director to the src folder. 
Then compile TriantaEna.java using the following code:
javac  TriantaEna.java
then run the code using:
java TriantaEna