Machine Learning CS542 Image Recognition project
Team Members: Joseph O'donnell, anonymous, Albert Sze, Eric Zhang
05/10/188

This image recognition code use images that have been categorized by Caltech. 
The code first reduces the image quality uses a kmeans algorithm, this reduces the 
number of unique color pixels from a potential 16m to 10 unique colors. the sklearn 
kmeans algorithm is used to determine the optimal cluster.

from here 20% of the photos are used to train the CNN. One contraint that was discovered,
was computing power, specifically memory limited. This limited the number of images that 
the model could be trained on efficiently.

The algorithm was able to identify 30% of the images correctly. In addition, it was discover
that training the model with reduced image qualities decreased the training time and still 
deliverd similar results compared to training with higher image quality.
